var blueBar = document.getElementsByClassName("_2t-a _26aw _5rmj _50ti _2s1y");
blueBar[0].style.backgroundColor = "darkcyan";
blueBar[0].style.borderBottom = "1px solid lightseagreen";

var _4ejcHeight = document.getElementById('pagelet_canvas_nav_content');
if(_4ejcHeight != null && _4ejcHeight != undefined)_4ejcHeight.style.height = '0px';

var _4ejc = document.getElementsByClassName("_4ejc");
if(_4ejc != null && _4ejc != undefined)_4ejc[0].style.display = "none";